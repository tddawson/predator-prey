Wow, you're actually reading me!

To use this program, just unzip this folder to extract the files.  Then, open index.html using 
a modern web browser such as Google Chrome.  The program should open exactly as you would see 
it online.  Adjust the sliders and click "Simulate" to graph predator (blue) and prey (red).  
After running one simulation, the "Compare to previous?" option will become available.  Check
the box to see the previous prey and predator data (as a thin line in the same colors) compared
to the new simulation.

The program is free to use for any purpose.  Feel free to modify the source code to change
the step size, graphical output, etc. to your liking.

Questions, comments, and suggestions can be directed to tddawson@gmail.com.

Thanks and enjoy!